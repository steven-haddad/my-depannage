<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{an_productattributes}prestashop>productattributes_2d0f6b8300be19cf35e89e66f0677f95'] = 'Ajouter au panier';
