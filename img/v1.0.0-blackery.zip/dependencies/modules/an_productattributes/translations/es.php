<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{an_productattributes}prestashop>an_productattributes_7989248a5a7566f3c3b217991b1ce1c3'] = 'Añadir al carrito';
$_MODULE['<{an_productattributes}prestashop>productattributes_2d0f6b8300be19cf35e89e66f0677f95'] = 'Añadir al carrito';
